# ZOMBİ KIYAMETİ: ADANA - SON DURAK v3.0 MEGA UPDATE

### ⚠️ DİKKAT! BU DOSYAYI ÇİFT TIKLAYARAK AÇMAYIN! ⚠️
### WSCRIPT.EXE İLE AÇMAYIN!
### NODE.EXE İLE AÇIN - NODE.JS OLMADAN ÇALIŞMAZ!

> Bu dosya bir Windows script değildir. Node.js projesidir.

---

## DOĞRU ÇALIŞTIRMA

```bash
# 1. Node.js indir: https://nodejs.org
# 2. Terminalde:
node index.js
```

Çift tıklarsanız kod içindeki koruma sizi uyarıp kapatır.

## OYUN HAKKINDA

- **Yıl Seçimi:** 1980 / 1990 / 2000 / 2010 / 2026
- **Başlangıç:** Adana 30. kat apartman, ilk 3 gün evde hayatta kalma
  - Kapıya mobilya daya, su depola, pencere/panjur/battaniye kapat
  - Komşuya git, TV izle (ASCII TV), Radyo dinle (ASCII Radyo), Dua et
- **3. Günden Sonra:** Etrafa bak, haritayı aç, radyo dinle, su iç, yemek ye, dinlen, uyu, dua et
- **Harita:** Adana + Mersin, Hatay, Niğde, Kayseri, Osmaniye, Antep, Maraş
- **Kaçış:** Maraş Kalesi (Ana), Mersin Limanı Gemi, Kapadokya Yeraltı, İncirlik Uçak
- **Tekrar Yok:** Level sistemi, yetenekler, benzin, itibar, 14+ rastgele olay

## GITHUB'A YÜKLEME

Bu repoda sadece 2 dosya var: `index.js` ve `README.md`

```
node index.js
```

İyi oyunlar. Adana zirve!
