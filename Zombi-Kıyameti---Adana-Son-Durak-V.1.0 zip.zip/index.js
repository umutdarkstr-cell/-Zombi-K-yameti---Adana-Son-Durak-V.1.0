/* 
###############################################################################
#  DİKKAT! BU DOSYAYI WSCRIPT.EXE İLE AÇMAYIN! ÇİFT TIKLAMAYIN!                #
#  >>> NODE.JS OLMADAN ÇALIŞMAZ! <<<                                           #
#  DOĞRU: node index_3.js  veya baslat.bat                                     #
###############################################################################
*/
// WSCRIPT KORUMASI - Eğer biri çift tıklarsa uyarı ver ve kapat
try {
  if (typeof WScript !== 'undefined' || typeof ActiveXObject !== 'undefined') {
    WScript.Echo(
"╔════════════════════════════════════════════════════════════════╗\n" +
"║  HATALI AÇILIŞ!                                                ║\n" +
"║  Bu dosyayı çift tıklayarak AÇAMAZSIN!                         ║\n" +
"║                                                                ║\n" +
"║  DOĞRU YÖNTEM:                                                 ║\n" +
"║  1. Node.js indir: https://nodejs.org                          ║\n" +
"║  2. Klasörde Shift+Sağ tık -> PowerShell aç                     ║\n" +
"║  3. Yaz: node index_3.js                                        ║\n" +
"║  VEYA baslat.bat dosyasına çift tıkla                          ║\n" +
"║                                                                ║\n" +
"║  NODE.JS OLMADAN ÇALIŞMAZ!                                     ║\n" +
"╚════════════════════════════════════════════════════════════════╝"
    );
    WScript.Quit(1);
  }
} catch(e) {}

// ZOMBİ KIYAMETİ: ADANA - SON DURAK v3.0 MEGA UPDATE
const readline = require('readline');
const fs = require('fs');
const path = require('path');
const VERSION = "3.0.0 - MEGA UPDATE V3";

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = (q) => new Promise(res => rl.question(q, ans => res(ans.trim())));

const COLORS = {
  reset: "\x1b[0m", red: "\x1b[31m", green: "\x1b[32m", yellow: "\x1b[33m",
  blue: "\x1b[34m", magenta: "\x1b[35m", cyan: "\x1b[36m",
  white: "\x1b[37m", gray: "\x1b[90m", bold: "\x1b[1m", bgRed: "\x1b[41m", bgBlue: "\x1b[44m", bgGreen: "\x1b[42m"
};
const c = (color, text) => COLORS[color] + text + COLORS.reset;
function sleep(ms){ return new Promise(r=>setTimeout(r, ms)); }
async function typewrite(text, delay=10){ for(let ch of text){ process.stdout.write(ch); await sleep(delay); } console.log(); }
function rand(min,max){ return Math.floor(Math.random()*(max-min+1))+min; }
function choice(arr){ return arr[Math.floor(Math.random()*arr.length)]; }
const SAVE_FILE = path.join(__dirname, 'kayit_v3.json');

// ============ YILLAR ============
const YILLAR = {
  "1980": { ad: "1980'ler RETRO", aciklama: "Siyah beyaz TV, gaz lambası. Zombiler çok yavaş ama bilgi yok.", teknoloji: -1, zombiCarpani: 0.6, baslangicEsya: ["gaz_lambasi","radyo_kaset","battaniye"], paraBirimi: "TL" },
  "1990": { ad: "1990'lar", aciklama: "Tüplü TV, kasetli radyo, bakkal defteri.", teknoloji: 0, zombiCarpani: 0.8, baslangicEsya: ["kaset_calar","bayat_ekmek","gaz_ocagi"], paraBirimi: "TL" },
  "2000": { ad: "2000'ler", aciklama: "Nokia 3310, internet kafe, MSN.", teknoloji: 1, zombiCarpani: 1.0, baslangicEsya: ["nokia_3310","enerji_icecegi","bicak"], paraBirimi: "TL" },
  "2010": { ad: "2010'lar", aciklama: "Akıllı telefon, Facebook.", teknoloji: 2, zombiCarpani: 1.2, baslangicEsya: ["akilli_telefon","powerbank","biber_gazi"], paraBirimi: "TL" },
  "2026": { ad: "2026 GÜNCEL - ZOR", aciklama: "Drone'lar, TikTok, BİO-LAB sızıntısı. En zor.", teknoloji: 3, zombiCarpani: 1.5, baslangicEsya: ["drone_kumandasi","paletli_telsiz","m4"], paraBirimi: "TL" },
};

// ============ ASCII TV / RADYO V3 ============
function asciiTV(sinyalVar=true, kanalMetni=""){
  if(!sinyalVar){
    console.log(c("cyan", `
    ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
    ┃  ╔═╗╔═╗╔═╗╦  ╦  ╔═╗╔═╗╦  ╦╔═╗╦═╗               ┃
    ┃  ╚═╗║  ║ ║║  ║  ╚═╗║ ║║  ║║ ║╠╦╝               ┃
    ┃  ╚═╝╚═╝╚═╝╩═╝╩  ╚═╝╚═╝╩═╝╩╚═╝╩╚═               ┃
    ┃                                             ┃
    ┃  ███████╗██╗███╗   ██╗██╗   ██╗ █████╗ ██╗    ┃
    ┃  ██╔════╝██║████╗  ██║╚██╗ ██╔╝██╔══██╗██║    ┃
    ┃  ███████╗██║██╔██╗ ██║ ╚████╔╝ ███████║██║    ┃
    ┃  ╚════██║██║██║╚██╗██║  ╚██╔╝  ██╔══██║██║    ┃
    ┃  ███████║██║██║ ╚████║   ██║   ██║  ██║█████┃
    ┃  ╚══════╝╚═╝╚═╝  ╚═══╝   ╚═╝   ╚═╝  ╚═╝╚════╝┃
    ┃                                             ┃
    ┃  [Anten düştü. Dışarıda fırtına var.]        ┃
    ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
    `));
    console.log(c("bgRed", "  >>> CIZIRTI... BZZZZT... YAYIN YOK <<<  "));
    return;
  }
  let scanline = rand(0,1) ? "▓▒░" : "░▒▓";
  console.log(c("yellow", `
    ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
    ┃  📺 TÜPLÜ TELEVİZYON - ${YILLAR[oyuncu.yil].ad.padEnd(20)}       ┃
    ┃  KANAL: ${String(oyuncu.tvKanal).padEnd(2)}  SİNYAL: %${rand(50,99)}  ${scanline}              ┃
    ┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
    ┃                                                 ┃
    ┃  ${kanalMetni.slice(0,42).padEnd(42)}  ┃
    ┃  ${kanalMetni.slice(42,84).padEnd(42)}  ┃
    ┃  ${kanalMetni.slice(84,126).padEnd(42)}  ┃
    ┃                                                 ┃
    ┃  ${"█".repeat(rand(5,35)).padEnd(42)}  ┃
    ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
  `));
  console.log(c("white", `  🎙️ SPİKER: "${kanalMetni}"`));
  if(kanalMetni.includes("Maraş")) console.log(c("green","  [HARİTA GÜNCELLENDİ: Maraş Kalesi işaretlendi!]"));
}

function asciiRadyo(frekans=87.5, metin=""){
  let dalga = "~".repeat(rand(3,10));
  console.log(c("magenta", `
      .------------------------------------------------.
     /  .--------------------------------------------.  \\
    |  /  o o o  [ ${frekans.toFixed(1)} FM ${dalga} ]  o o o  \\  |
    | |   ▓▓▓▓▓  📻 ADANA RADYO ${oyuncu.yil} ▓▓▓▓▓   | |
    | |   ((((  ANTEN: ${oyuncu.ev.anteniDuzeltildi ? "DİK ✓" : "YAMUK!"}  ))))   | |
    |  \\  o o o o o o o o o o o o o o o o o o o  /  |
     \\  '--------------------------------------------'  /
      '------------------------------------------------'
         ||  ||  PİL: %${oyuncu.ev.radyoPili}  ||
  `));
  console.log(c("cyan", `  📻: "${metin}"`));
}

// ============ HARİTA V3 - 35+ BÖLGE ============
const HARITA = {
  // ADANA APARTMAN
  "ev": { ad: "🏢 EVİN - Adana 30.Kat", aciklama: "Adana sıcağı camdan vuruyor. Balkondan tüm şehir görünüyor. Ev senin kalen.", baglanti: ["apartman_bosluk","cati","balkon"], loot: ["su","konserve","battaniye"], tehlike: 0, guvenli: true, sehir: "adana", kat: 30 },
  "balkon": { ad: "Balkon - 30.Kat Manzara", aciklama: "Dürbünle bak: Mersin yolu, Seyhan, dumanlar. Aşağıda zombiler karınca gibi.", baglanti: ["ev"], loot: ["dürbün","sigara"], tehlike: 1, sehir: "adana" },
  "apartman_bosluk": { ad: "Apartman Boşluğu 15.Kat", aciklama: "Asansör düşmüş. Komşu Ayşe Teyze'nin kapısı aralık.", baglanti: ["ev","seyhan_sokak","komşu_ayse"], loot: ["levye","anahtar"], tehlike: 2, sehir: "adana" },
  "komşu_ayse": { ad: "Ayşe Teyze'nin Evi", aciklama: "Salça kokuyor. Teyze sağ mı?", baglanti: ["apartman_bosluk"], loot: ["ekmek","salca","otobus_bileti"], tehlike: 1, guvenli: true, sehir: "adana" },
  "cati": { ad: "Apartman Çatısı", aciklama: "Çanak antenler, helikopter enkazı.", baglanti: ["ev"], loot: ["isaret_fisegi","halat"], tehlike: 1, sehir: "adana" },

  // ADANA MERKEZ
  "adana_hastane": { ad: "Çukurova Devlet Hastanesi", aciklama: "Jeneratör uğulduyor.", baglanti: ["seyhan_sokak","hastane_cati","bodrum","eczane"], loot: ["ilac","sargi"], tehlike: 3, sehir: "adana" },
  "eczane": { ad: "Hastane Eczanesi", aciklama: "Kapısı kırılmış, ilaçlar dağılmış.", baglanti: ["adana_hastane"], loot: ["ilac","morfın","kutsal_su"], tehlike: 3, sehir: "adana" },
  "seyhan_sokak": { ad: "Seyhan Nehri Kenarı", aciklama: "Terk edilmiş arabalar.", baglanti: ["adana_hastane","buyuk_saat","baraj_yolu","apartman_bosluk"], loot: ["su","konserve"], tehlike: 2, sehir: "adana" },
  "buyuk_saat": { ad: "Büyük Saat Meydanı", aciklama: "Saat durmuş: 03:17.", baglanti: ["seyhan_sokak","kapali_carsi","tren_gari","kebapcilar"], loot: ["paletli_telsiz","bicak"], tehlike: 4, sehir: "adana" },
  "kapali_carsi": { ad: "Kapalı Çarşı", aciklama: "Baharat ve çürüme kokusu.", baglanti: ["buyuk_saat","tepebag","bakkal"], loot: ["baharat","cakmak","tuz"], tehlike: 2, sehir: "adana" },
  "bakkal": { ad: "Köşe Bakkal - Veresiye Defteri", aciklama: "Bakkal amca not bırakmış: 'Borçlar silindi, helal olsun.'", baglanti: ["kapali_carsi"], loot: ["ekmek","konserve","su"], tehlike: 1, guvenli: true, sehir: "adana" },
  "tepebag": { ad: "Tepebağ Güvenli Bölge", aciklama: "Yaşlılar barikat kurmuş.", baglanti: ["kapali_carsi"], loot: ["ekmek","zeytin"], tehlike: 1, guvenli: true, sehir: "adana" },
  "tren_gari": { ad: "Tren Garı", aciklama: "Son tren raydan çıkmış.", baglanti: ["buyuk_saat","otogar"], loot: ["levye"], tehlike: 5, sehir: "adana" },
  "otogar": { ad: "Adana Otogarı - ANA KAVŞAK", aciklama: "Anons: 'Mersin, Hatay, Niğde, Maraş seferleri...' Tüm şehirler buradan.", baglanti: ["tren_gari","incirlik_yolu","mersin_yolu","hatay_yolu","nigde_yolu","maras_yolu"], loot: ["benzin","harita","otobus_bileti"], tehlike: 3, sehir: "adana" },
  "incirlik_yolu": { ad: "İncirlik Yolu", aciklama: "Tank terk edilmiş.", baglanti: ["otogar","incirlik_ussu"], loot: ["m4"], tehlike: 5, sehir: "adana" },
  "incirlik_ussu": { ad: "İncirlik Üssü - FİNAL", aciklama: "Son yayın buradan.", baglanti: ["incirlik_yolu"], loot: ["final"], tehlike: 10, final: true, sehir: "adana" },
  "hastane_cati": { ad: "Hastane Çatısı", aciklama: "Helikopter enkazı.", baglanti: ["adana_hastane"], loot: ["dürbün"], tehlike: 2, sehir: "adana" },
  "bodrum": { ad: "Hastane Morgu", aciklama: "Torbalar hareket ediyor.", baglanti: ["adana_hastane"], loot: ["anahtar"], tehlike: 4, sehir: "adana" },
  "baraj_yolu": { ad: "Baraj Gölü Yolu", aciklama: "Balıkçı kulübesi var.", baglanti: ["seyhan_sokak","balikci_kulubesi","cukurova_uni"], loot: ["olta"], tehlike: 2, sehir: "adana" },
  "balikci_kulubesi": { ad: "Balıkçı Kulübesi", aciklama: "Günlükler.", baglanti: ["baraj_yolu"], loot: ["gunluk"], tehlike: 1, guvenli: true, sehir: "adana" },
  "cukurova_uni": { ad: "Çukurova Üni.", aciklama: "Kütüphane barikatlı.", baglanti: ["baraj_yolu","sabanci_camii"], loot: ["kitap"], tehlike: 3, sehir: "adana" },
  "sabanci_camii": { ad: "Sabancı Merkez Camii", aciklama: "İçi sığınak olmuş.", baglanti: ["cukurova_uni"], loot: ["hurma","tesbih"], tehlike: 2, guvenli: true, sehir: "adana" },
  "kebapcilar": { ad: "Kebapçılar Sokağı", aciklama: "Zombi kebapçı!", baglanti: ["buyuk_saat"], loot: ["kebap"], tehlike: 4, sehir: "adana" },

  // MERSİN
  "mersin_yolu": { ad: "🛣️ D400 Mersin Yolu", aciklama: "65km. Deniz kokusu.", baglanti: ["otogar","mersin_limani","tarsus","osmaniye_yolu"], loot: ["benzin"], tehlike: 4, sehir: "mersin" },
  "mersin_limani": { ad: "Mersin Limanı - KAÇIŞ", aciklama: "Son gemi kalkıyor! Yakıt lazım.", baglanti: ["mersin_yolu","mersin_marina"], loot: ["halat","isaret_fisegi"], tehlike: 6, sehir: "mersin", kacis: true, final: true },
  "mersin_marina": { ad: "Mersin Marina", aciklama: "Yat sahibi: 'Kıbrıs'a kaçıcam.'", baglanti: ["mersin_limani"], loot: ["olta"], tehlike: 3, guvenli: true, sehir: "mersin" },
  "tarsus": { ad: "Tarsus Şelale", aciklama: "Kutsal su burada.", baglanti: ["mersin_yolu"], loot: ["kutsal_su"], tehlike: 4, sehir: "mersin" },
  "osmaniye_yolu": { ad: "Osmaniye Kavşağı", aciklama: "Yeni şehir: Osmaniye ve Antep'e ayrılır.", baglanti: ["mersin_yolu","osmaniye_merkez","antep_yolu"], loot: ["benzin"], tehlike: 4, sehir: "osmaniye" },
  "osmaniye_merkez": { ad: "Osmaniye Kalesi", aciklama: "Küçük kale, direniyor.", baglanti: ["osmaniye_yolu"], loot: ["mermi","ekmek"], tehlike: 3, guvenli: true, sehir: "osmaniye" },

  // HATAY
  "hatay_yolu": { ad: "🛣️ Hatay İskenderun Yolu", aciklama: "Yanmış konvoy.", baglanti: ["otogar","hatay_merkez","iskenderun"], loot: ["m4"], tehlike: 5, sehir: "hatay" },
  "hatay_merkez": { ad: "Antakya Harbiye", aciklama: "Mozaikler altında sığınak.", baglanti: ["hatay_yolu","hatay_muze"], loot: ["mozaik_parcasi"], tehlike: 5, sehir: "hatay" },
  "hatay_muze": { ad: "Hatay Arkeoloji Müzesi", aciklama: "Mozaikler arasında yaşayanlar var.", baglanti: ["hatay_merkez"], loot: ["antik_para","fener"], tehlike: 4, guvenli: true, sehir: "hatay" },
  "iskenderun": { ad: "İskenderun Sahili", aciklama: "NATO gemisi batmış.", baglanti: ["hatay_yolu"], loot: ["celik_yel"], tehlike: 6, sehir: "hatay" },

  // NİĞDE / KAPADOKYA
  "nigde_yolu": { ad: "🛣️ E90 Niğde Yolu", aciklama: "Toroslar, soğuk. Yeraltı şehri güvenli.", baglanti: ["otogar","nigde_merkez","kapadokya","kayseri_yolu"], loot: ["battaniye"], tehlike: 3, sehir: "nigde" },
  "nigde_merkez": { ad: "Niğde Eski Ev", aciklama: "Sobada odun yanıyor. 'Maraş'a tünel var' diyorlar.", baglanti: ["nigde_yolu"], loot: ["komur"], tehlike: 2, guvenli: true, sehir: "nigde" },
  "kapadokya": { ad: "Kapadokya Yeraltı Şehri - KAÇIŞ", aciklama: "Derinkuyu, mükemmel saklanma. Fenersiz kaybolursun.", baglanti: ["nigde_yolu"], loot: ["antik_para"], tehlike: 4, guvenli: true, sehir: "nigde", kacis: true, final: true },
  "kayseri_yolu": { ad: "Kayseri Yolu - Erciyes", aciklama: "Kar fırtınası. Erciyes'te kayak oteli sığınak olmuş.", baglanti: ["nigde_yolu","erciyes_otel"], loot: ["battaniye","kayak"], tehlike: 5, sehir: "kayseri" },
  "erciyes_otel": { ad: "Erciyes Kayak Oteli", aciklama: "Sıcak havuz, jeneratör, 20 kişi hayatta.", baglanti: ["kayseri_yolu"], loot: ["konserve","ilac"], tehlike: 2, guvenli: true, sehir: "kayseri" },

  // MARAŞ - ANA KAÇIŞ
  "maras_yolu": { ad: "🛣️ Maraş Yolu - ANA KAÇIŞ ROTASI", aciklama: "Askerler: 'Maraş kalesi sağlam!' 200km ölüm yolu.", baglanti: ["otogar","nigde_yolu","maras_kale","maras_carsi"], loot: ["benzin"], tehlike: 7, sehir: "maras" },
  "maras_carsi": { ad: "Maraş Çarşısı", aciklama: "Dondurmacılar kepenk kapatmış ama dondurma sağlam!", baglanti: ["maras_yolu"], loot: ["maras_dondurma","kebap"], tehlike: 3, sehir: "maras" },
  "maras_kale": { ad: "🏰 KAHRAMANMARAŞ KALESİ - SON KALE", aciklama: "Bayrak dalgalanıyor. Yüzlerce insan, ordu, çorba ve UMUT. Burası YENİ BAŞLANGIÇ.", baglanti: ["maras_yolu"], loot: ["final"], tehlike: 8, final: true, kacis: true, guvenli: true, sehir: "maras" },

  // ANTEP
  "antep_yolu": { ad: "🛣️ Gaziantep Yolu", aciklama: "Baklava kokusu geliyor... ama yanık karışmış.", baglanti: ["osmaniye_yolu","antep_merkez"], loot: ["benzin"], tehlike: 6, sehir: "antep" },
  "antep_merkez": { ad: "Antep Bakırcılar Çarşısı", aciklama: "Bakır ustaları barikat yapmış. Direniyorlar.", baglanti: ["antep_yolu"], loot: ["bakir_zirh","kebap"], tehlike: 5, guvenli: true, sehir: "antep" },
};

const ZOMBI_TURLERI = {
  yuruyen: { ad: "Yürüyen", can: 30, hasar: [5,12], hiz: 1, aciklama: "Klasik." },
  kosucu: { ad: "Koşucu", can: 45, hasar: [10,18], hiz: 3, aciklama: "Çok hızlı!" },
  siskan: { ad: "Şişkin", can: 90, hasar: [15,30], hiz: 1, aciklama: "Patlar!" },
  hayalet: { ad: "Gölge", can: 25, hasar: [8,25], hiz: 4, aciklama: "Görünmez." },
  zirhli: { ad: "Çevik Kuvvet", can: 120, hasar: [12,20], hiz: 1, aciklama: "Zırhlı." },
  bagiran: { ad: "Bağıran", can: 50, hasar: [5,10], hiz: 2, aciklama: "Sürü çağırır!" },
  kebapci: { ad: "Kebapçı", can: 70, hasar: [18,28], hiz: 2, aciklama: "Şişli!" },
  taraftar: { ad: "Taraftar", can: 100, hasar: [10,22], hiz: 3, aciklama: "Şimşek!" },
  cocuk: { ad: "Çocuk Zombi", can: 20, hasar: [3,8], hiz: 4, aciklama: "Küçük, hızlı." },
  itfaiyeci: { ad: "İtfaiyeci", can: 80, hasar: [15,25], hiz: 2, aciklama: "Baltalı." },
  doktor: { ad: "Doktor", can: 60, hasar: [10,30], hiz: 2, aciklama: "Enfeksiyon bulaştırır." },
  asker: { ad: "Zombi Asker", can: 110, hasar: [20,35], hiz: 2, aciklama: "M4'lü, çok tehlikeli!" },
};

const ESYALAR = {
  su: { ad: "Su", tur: "tuketim", deger: 25 }, konserve: { ad: "Konserve", tur: "tuketim", deger: 30 },
  ekmek: { ad: "Ekmek", tur: "tuketim", deger: 15 }, ilac: { ad: "Antibiyotik", tur: "tuketim", deger: 40 },
  sargi: { ad: "Sargı", tur: "tuketim", deger: 20 }, bicak: { ad: "Bıçak", tur: "silah", hasar: [12,18], dayaniklilik: 100 },
  levye: { ad: "Levye", tur: "silah", hasar: [15,20], dayaniklilik: 200 }, m4: { ad: "M4", tur: "silah", hasar: [25,40], dayaniklilik: 150 },
  benzin: { ad: "Benzin", tur: "malzeme" }, cakmak: { ad: "Çakmak", tur: "arac" }, dürbün: { ad: "Dürbün", tur: "arac" },
  paletli_telsiz: { ad: "Telsiz", tur: "gorev" }, kebap: { ad: "Kebap", tur: "tuketim", deger: 50 },
  battaniye: { ad: "Battaniye", tur: "malzeme" }, otobus_bileti: { ad: "Otobüs Bileti", tur: "gorev" },
  fener: { ad: "Fener", tur: "arac" }, halat: { ad: "Halat", tur: "malzeme" },
  gaz_lambasi: { ad: "Gaz Lambası", tur: "arac" }, kaset_calar: { ad: "Kaset Çalar", tur: "arac" },
  nokia_3310: { ad: "Nokia 3310", tur: "arac" }, akilli_telefon: { ad: "Akıllı Telefon", tur: "arac" },
  powerbank: { ad: "Powerbank", tur: "malzeme" }, biber_gazi: { ad: "Biber Gazı", tur: "silah", hasar: [5,10], dayaniklilik: 3 },
  drone_kumandasi: { ad: "Drone Kumandası", tur: "arac" }, kutsal_su: { ad: "Kutsal Su", tur: "tuketim", deger: 100 },
  mozaik_parcasi: { ad: "Mozaik", tur: "gorev" }, antik_para: { ad: "Antik Para", tur: "malzeme" },
  maras_dondurma: { ad: "Maraş Dondurması", tur: "tuketim", deger: 60 }, bakir_zirh: { ad: "Bakır Zırh", tur: "zirh", koruma: 15 },
  komur: { ad: "Kömür", tur: "malzeme" }, salca: { ad: "Salça", tur: "tuketim", deger: 20 },
  gaz_ocagi: { ad: "Gaz Ocağı", tur: "arac" }, sigara: { ad: "Sigara", tur: "arac" },
  isaret_fisegi: { ad: "İşaret Fişeği", tur: "arac" }, cakmak: { ad: "Çakmak", tur: "arac" },
  mermi: { ad: "Mermi 5.56", tur: "malzeme" }, anahtar: { ad: "Anahtar", tur: "gorev" },
  gunluk: { ad: "Günlük", tur: "gorev" }, tesbih: { ad: "Tesbih", tur: "arac" },
};

let oyuncu = {
  ad: "İsimsiz", yil: "2026", can: 100, maxCan: 100, aclik: 100, susuzluk: 100, moral: 80, yorgunluk: 0, seviye: 1, xp: 0,
  konum: "ev", ev: { barikat: 0, suDeposu: 0, pencere: 0, panjur: false, battaniye: false, elektrik: true, komsuIliski: 50, anteniDuzeltildi: false, radyoPili: 100 },
  tvKanal: 1, frekans: 87.5, envanter: ["bicak","su","su","battaniye"], silah: "bicak", arac: null, benzin: 0,
  mermi: { "5.56mm": 30 }, gun: 1, saat: 8, oldurme: 0, enfeksiyon: 0, kesfedilen: ["ev"], bitirdiMi: false,
  yetenekler: { guc: 1, hiz: 1, zeka: 1, dayaniklilik: 1 }, gorevler: [], hava: "Sıcak 45°C", para: 50, itibar: { adana: 0, mersin: 0, maras: 0, hatay: 0, nigde: 0 },
};

function durumCubugu(d, max=100){ let dolu=Math.round((d/max)*10); let renk=d>60?"green":d>30?"yellow":"red"; return c(renk, "["+"█".repeat(dolu)+"░".repeat(10-dolu)+`] ${d}%`); }
function oyuncuDurum(){
  console.log("\n"+c("bold", `=== ${oyuncu.ad} | ${YILLAR[oyuncu.yil].ad} | Lv.${oyuncu.seviye} XP:${oyuncu.xp} | Gün ${oyuncu.gun} ${oyuncu.saat}:00 | ${oyuncu.hava} ===`));
  console.log(c("green", `Can:${durumCubugu(oyuncu.can)}`)+(oyuncu.enfeksiyon>0?c("red",` ENF ${oyuncu.enfeksiyon}%`):"")+c("gray",` Yorgun:${oyuncu.yorgunluk}%`));
  console.log(c("yellow", `Açlık:${durumCubugu(oyuncu.aclik)} Susuzluk:${durumCubugu(oyuncu.susuzluk)} Moral:${durumCubugu(oyuncu.moral)}`));
  console.log(c("cyan", `Konum:${HARITA[oyuncu.konum].ad} | Kill:${oyuncu.oldurme} | Benzin:${oyuncu.benzin}L | Para:${oyuncu.para}TL | İtibar Maraş:${oyuncu.itibar.maras}`));
  if(oyuncu.konum==="ev") console.log(c("magenta", `EV: Barikat %${oyuncu.ev.barikat} Su:${oyuncu.ev.suDeposu}L Pencere %${oyuncu.ev.pencere} Panjur:${oyuncu.ev.panjur?"Kapalı":"Açık"}`));
  console.log(c("gray", `Çanta: ${oyuncu.envanter.map(i=>ESYALAR[i]?.ad||i).join(", ")||"Boş"} | Silah: ${ESYALAR[oyuncu.silah]?.ad||"Yumruk"}`));
}

const TV_KANALLARI = {
  "1980": ["TRT: Sayın seyirciler, Adana'da garip olaylar...","SİNYAL YOK - Antene çıkıp düzelt!","Ajanda: Adana'da pamuk hasadı."],
  "1990": ["TRT: Dışarıda garip olaylar var ama halay çekiyoruz...","Haber: Kebap fiyatları arttı, insanlar ısırıyor mu?","SİNYAL YOK - Anteni çevir!"],
  "2000": ["Kanal D: Adana'da virüs! Seyhan Nehri kirlilik mi zombi mi?","SİNYAL ZAYIF - Nokia çekiyor mu?","Son Dakika: İncirlik karantinada!"],
  "2010": ["Facebook TT: #AdanaZombi gerçek mi?","Müge Anlı: Kayıp şahıs artık yürüyor!","Fiber kesildi, modemi resetle!"],
  "2026": ["SON DAKİKA: BİO-LAB patladı! Virüs havada!","TikTok Canlı: Büyük Saat'te 100 zombi!","Askeri Frekans: Tüm siviller Maraş Kalesi'ne! 48 saat!","Mersin Limanı son gemi kalkıyor!","Hatay düştü... Niğde yeraltı şehri güvenli!"],
};
const RADYO_MESAJLARI = [
  "Cızırtı... İncirlik... 06:00 son tahliye...",
  "Mersin Limanı... Bir gemi var... Yakıt yok...",
  "Hatay... Mozaikler altında saklanıyoruz...",
  "Niğde Yeraltı... Burası güvenli... Soğuk ama güvenli...",
  "Kahramanmaraş Kalesi... Kale sağlam! Ordu burada! Maraş'a gelin! 200km!",
  "Adana Otogarı... Otobüsler çalışmıyor... Anahtar Tepebağ'da...",
  "Hava 45 derece... Zombiler sıcakta yavaş...",
  "İncirlik kod 4721... Üs kapısı için...",
  "Osmaniye'den: Antep'e giden yol açık, bakır zırh yapıyorlar!",
  "Kayseri Erciyes Otel... Sıcak havuz, jeneratör... Gelin!",
  "Gaziantep direniyor! Baklava bedava diyorlar!",
];

function lootYap(bolge){ if(rand(1,10)<4) return; let list=HARITA[bolge].loot; if(!list||!list.length) return; let item=choice(list); if(item==="final") return; oyuncu.envanter.push(item); console.log(c("green", `\n[GANİMET] ${ESYALAR[item]?.ad||item} buldun!`)); }

async function savas(zombiTipi, adet=1){
  let proto=ZOMBI_TURLERI[zombiTipi]; let carp=YILLAR[oyuncu.yil].zombiCarpani;
  let zombiler=[]; for(let i=0;i<adet;i++) zombiler.push({...proto, can: Math.floor((proto.can+rand(-10,20))*carp), hasar:[Math.floor(proto.hasar[0]*carp),Math.floor(proto.hasar[1]*carp)], id:i+1});
  console.log(c("bgRed", `\n!!! ${adet}x ${proto.ad} saldırıyor !!! ${proto.aciklama}`));
  while(zombiler.length>0 && oyuncu.can>0){
    console.log(c("red", `\n--- SAVAŞ [${zombiler.map(z=>z.ad+":"+z.can).join(", ")}] ---`));
    console.log("[E] Saldır [K] Kaç [Ç] Çanta [B] Bağır [D] Dua et");
    let sec=(await ask("> ")).toLowerCase();
    if(sec==="k"){ if(rand(1,10)>3){ console.log(c("green","Kaçtın!")); oyuncu.saat+=1; oyuncu.yorgunluk+=10; return true; } else console.log(c("red","Kaçamadın!")); }
    else if(sec==="ç"){ await envanterKullan(true); }
    else if(sec==="b"){ console.log(c("yellow","'ADANA ZİRVEE!'")); oyuncu.moral+=5; if(zombiTipi==="bagiran"){ zombiler.push({...proto, can:proto.can, id:zombiler.length+1}); console.log(c("red","+1 zombi geldi!")); } }
    else if(sec==="d"){ console.log(c("cyan","Dua ettin...")); oyuncu.moral=Math.min(100, oyuncu.moral+15); oyuncu.can=Math.min(100, oyuncu.can+5); }
    else { let silah=ESYALAR[oyuncu.silah]||{hasar:[5,8]}; let hasar=rand(silah.hasar[0], silah.hasar[1])+oyuncu.yetenekler.guc; let hedef=zombiler[0]; hedef.can-=hasar; console.log(c("green", `${hedef.ad}'ye ${hasar} hasar!`)); if(hedef.can<=0){ console.log(c("cyan",`${hedef.ad} öldü! +${10*oyuncu.seviye} XP`)); zombiler.shift(); oyuncu.oldurme++; oyuncu.xp+=10; oyuncu.moral+=2; if(oyuncu.xp>=oyuncu.seviye*100){ oyuncu.seviye++; oyuncu.maxCan+=10; oyuncu.can=oyuncu.maxCan; console.log(c("bgGreen",` LEVEL UP! Seviye ${oyuncu.seviye} oldun! Can +10`)); } } }
    for(let z of zombiler){ if(oyuncu.can<=0) break; let dmg=rand(z.hasar[0], z.hasar[1]) - (ESYALAR[oyuncu.silah]?.koruma||0); dmg=Math.max(1,dmg); oyuncu.can-=dmg; oyuncu.enfeksiyon+= (zombiTipi==="siskan"||zombiTipi==="doktor"?8:2); console.log(c("red", `${z.ad} sana ${dmg} vurdu!`)); if(zombiTipi==="siskan"&&z.can<20&&rand(1,2)===1){ console.log(c("bgRed","ŞİŞKİN PATLADI!")); oyuncu.can-=15; z.can=0; } }
    zombiler=zombiler.filter(z=>z.can>0);
  }
  if(oyuncu.can<=0){ await olumEkrani(); return false; } else { console.log(c("green","\nTemizlendi.")); lootYap(oyuncu.konum); return true; }
}

async function envanterKullan(savastaMi=false){
  if(!oyuncu.envanter.length){ console.log("Boş."); return; }
  console.log("\nÇanta:"); oyuncu.envanter.forEach((id,i)=>console.log(` ${i+1}. ${ESYALAR[id]?.ad||id} - ${ESYALAR[id]?.tur}`));
  let sec=await ask("Kullan (0 iptal): "); let idx=parseInt(sec)-1; if(isNaN(idx)||idx<0||idx>=oyuncu.envanter.length) return;
  let itemId=oyuncu.envanter[idx]; let item=ESYALAR[itemId]; if(!item){ oyuncu.envanter.splice(idx,1); return; }
  if(item.tur==="tuketim"){ 
    if(["su","kutsal_su"].includes(itemId)) oyuncu.susuzluk=Math.min(100, oyuncu.susuzluk+item.deger);
    else oyuncu.aclik=Math.min(100, oyuncu.aclik+item.deger);
    if(itemId==="ilac"){ oyuncu.can=Math.min(100, oyuncu.can+item.deger); oyuncu.enfeksiyon=Math.max(0, oyuncu.enfeksiyon-15); }
    if(itemId==="kutsal_su") oyuncu.enfeksiyon=0;
    if(itemId==="maras_dondurma"){ oyuncu.moral=Math.min(100, oyuncu.moral+30); oyuncu.aclik=Math.min(100, oyuncu.aclik+20); }
    console.log(c("green", `${item.ad} yendi/içildi.`)); oyuncu.envanter.splice(idx,1);
  } else if(item.tur==="silah"){ oyuncu.silah=itemId; console.log(c("cyan", `${item.ad} kuşanıldı.`)); }
  else { console.log(item.ad+" : "+(item.tur)); if(itemId==="tesbih") oyuncu.moral+=10; }
}

// ============ İLK 3 GÜN EV ============
async function ilkUcGunEv(){
  console.log(c("bgBlue", `\n=== GÜN ${oyuncu.gun} - EVDE HAYATTA KALMA (İlk 3 Gün) - 30.Kat ===`));
  while(oyuncu.gun<=3){
    oyuncuDurum();
    console.log(c("white", `\nEvde ne yapacaksın? Gün ${oyuncu.gun}/3`));
    console.log(" [1] Kapıya mobilya daya (Barikat +15)");
    console.log(" [2] Musluğu aç ve su depola (Su +20L)");
    console.log(" [3] Dışarı çık (Gün 3 sonrası önerilir)");
    console.log(" [4] Komşuya git (Bilgi/takas)");
    console.log(" [5] TV izle - Bilgi topla [ASCII TV]");
    console.log(" [6] Dua et");
    console.log(" [7] Pencereleri kapat / Panjur / Battaniye");
    console.log(" [8] Radyo dinle [ASCII Radyo]");
    console.log(" [9] Uyuyup sonraki güne geç");
    console.log(" [10] Araç kontrol (varsa)");
    let sec=await ask("> ");
    if(sec==="1"){ oyuncu.ev.barikat=Math.min(100, oyuncu.ev.barikat+15+rand(0,10)); oyuncu.yorgunluk+=10; oyuncu.saat+=2; console.log(c("green",`Barikat %${oyuncu.ev.barikat}`)); }
    else if(sec==="2"){ if(oyuncu.ev.suDeposu>=100){ console.log("Dolu"); continue; } if(!oyuncu.ev.elektrik){ console.log(c("red","Elektrik kesik, su gelmiyor!")); continue; } oyuncu.ev.suDeposu=Math.min(100, oyuncu.ev.suDeposu+20+rand(0,15)); oyuncu.saat+=1; console.log(c("cyan",`Su deposu ${oyuncu.ev.suDeposu}L`)); if(oyuncu.gun===2&&rand(1,10)>7){ oyuncu.ev.elektrik=false; console.log(c("red","[OLAY] Elektrik kesildi!")); } }
    else if(sec==="3"){ if(oyuncu.gun<3){ let emin=await ask("Erken! Emin misin? e/h: "); if(emin!=="e") continue; } oyuncu.konum="apartman_bosluk"; break; }
    else if(sec==="4"){
      console.log(c("yellow","15.kat Ayşe Teyze...")); let olay=rand(1,5);
      if(olay===1){ console.log(c("green","Teyze: Al ekmek, Maraş'a kaç!")); oyuncu.envanter.push("ekmek","konserve"); oyuncu.ev.komsuIliski+=10; }
      else if(olay===2){ console.log(c("red","İçeride bir şey var!")); await savas("yuruyen",rand(1,2)); }
      else if(olay===3){ console.log(c("cyan","Teyze: Otobüs bileti buldum.")); oyuncu.envanter.push("otobus_bileti"); }
      else if(olay===4){ console.log(c("gray","Tesbih ve su var.")); oyuncu.envanter.push("tesbih","su"); }
      else { console.log(c("red","Komşu zombi!")); await savas("cocuk",1); }
      oyuncu.saat+=1;
    }
    else if(sec==="5"){ let kanallar=TV_KANALLARI[oyuncu.yil]||TV_KANALLARI["2026"]; let sinyal=!(oyuncu.gun>2&&rand(1,10)>6); let metin=choice(kanallar); oyuncu.tvKanal=rand(1,8); asciiTV(sinyal, metin); if(metin.includes("Maraş")&&!oyuncu.kesfedilen.includes("maras_yolu")){ oyuncu.kesfedilen.push("maras_yolu"); console.log(c("green","Maraş rotası açıldı!")); } oyuncu.moral+=5; oyuncu.saat+=1; }
    else if(sec==="6"){ console.log(c("cyan","Ellerini açtın dua ettin...")); oyuncu.moral=Math.min(100, oyuncu.moral+15); oyuncu.yorgunluk=Math.max(0, oyuncu.yorgunluk-5); oyuncu.saat+=1; }
    else if(sec==="7"){ console.log(" [a] Pencere kapat [b] Panjur [c] Battaniye"); let alt=await ask("Seç: "); if(alt==="a"){ oyuncu.ev.pencere=Math.min(100, oyuncu.ev.pencere+25); console.log(c("green","Pencereler bantlandı.")); } else if(alt==="b"){ oyuncu.ev.panjur=true; console.log(c("green","Panjur indi.")); } else if(alt==="c"){ if(oyuncu.envanter.includes("battaniye")){ oyuncu.ev.battaniye=true; oyuncu.ev.pencere=Math.min(100, oyuncu.ev.pencere+40); oyuncu.envanter.splice(oyuncu.envanter.indexOf("battaniye"),1); console.log(c("green","Battaniye çakıldı, zifiri karanlık ama güvenli.")); } else console.log(c("red","Battaniyen yok!")); } oyuncu.saat+=1; }
    else if(sec==="8"){ oyuncu.frekans=rand(875,1080)/10; let mesaj=choice(RADYO_MESAJLARI); asciiRadyo(oyuncu.frekans, mesaj); oyuncu.ev.radyoPili=Math.max(0, oyuncu.ev.radyoPili-5); if(mesaj.includes("Maraş")&&!oyuncu.kesfedilen.includes("maras_yolu")){ oyuncu.kesfedilen.push("maras_yolu"); console.log(c("green","Maraş eklendi!")); } oyuncu.saat+=1; }
    else if(sec==="9"){ console.log(c("yellow",`Gün ${oyuncu.gun} bitti...`)); oyuncu.gun+=1; oyuncu.saat=8; oyuncu.aclik-=15; oyuncu.susuzluk-=15; oyuncu.yorgunluk=0; oyuncu.hava=choice(["Çok Sıcak 45°C","Kum Fırtınası","Ayaz","Dumanlı"]); if(oyuncu.ev.barikat<30&&oyuncu.gun===2){ console.log(c("red","[GECE SALDIRISI] Kapı zorlanıyor!")); await savas("yuruyen",2); } if(oyuncu.gun===4) break; }
    else if(sec==="10"){ if(oyuncu.arac) console.log(c("cyan",`Aracın: ${oyuncu.arac} Benzin: ${oyuncu.benzin}L`)); else console.log("Henüz aracın yok, otogarda bulabilirsin."); }
    if(oyuncu.can<=0) await olumEkrani();
  }
  console.log(c("bgRed","\n=== 3 GÜN BİTTİ - ARTIK DIŞARI ÇIKMALISIN! Radyo: MARAŞ KALESİ GÜVENLİ! ==="));
  oyuncu.konum="apartman_bosluk";
}

// ============ V3 YENİ OLAYLAR - TEKRARI BİTİREN ============
async function rastgeleOlayV3(){
  if(rand(1,10)<7){
    let olaylar = [
      async () => { console.log(c("yellow","\n[OLAY] Terk edilmiş bakkal, bedava kebap!")); oyuncu.envanter.push("kebap"); oyuncu.moral+=10; },
      async () => { console.log(c("green","\n[OLAY] Sokak köpeği seni güvenli bölgeye götürdü!")); oyuncu.konum=choice(["tepebag","balikci_kulubesi","sabanci_camii"]); },
      async () => { console.log(c("magenta","\n[OLAY] Yağmur! Susuzluk -20 ama enfeksiyon +5")); oyuncu.susuzluk=Math.max(0, oyuncu.susuzluk-20); oyuncu.enfeksiyon+=5; },
      async () => { console.log(c("yellow","\n[OLAY] Radyo frekans: 103.8 'Maraş'a giden otobüs... şoförü ısırılmış...'")); },
      async () => { console.log(c("red","\n[OLAY] Hırsızlar!")); if(oyuncu.envanter.length>0&&rand(1,2)===1){ let cal=oyuncu.envanter.pop(); console.log(c("red",`${ESYALAR[cal]?.ad||cal} çalındı!`)); } },
      async () => { console.log(c("cyan","\n[OLAY] Drone düştü! Kumandan varsa kullan.")); if(oyuncu.envanter.includes("drone_kumandasi")){ oyuncu.kesfedilen.push(choice(["hatay_merkez","nigde_merkez"])); console.log(c("green","Yeni yer keşfedildi!")); } },
      async () => { console.log(c("white","\n[OLAY] Günlük: 'Maraş kalesi... oraya varırsam ailem yaşayacak...'")); oyuncu.moral+=5; },
      async () => { console.log(c("yellow","\n[OLAY] Seyyar satıcı zombi!")); await savas("taraftar",1); },
      async () => { console.log(c("green","\n[OLAY] Askeri kasa buldun! İçinde mermi!")); oyuncu.mermi["5.56mm"]+=20; },
      async () => { console.log(c("blue","\n[OLAY] Tüccar! Takas yapmak ister misin?")); let sec=await ask("Takas? 1 konserve = 1 benzin? (e/h): "); if(sec==="e"&&oyuncu.envanter.includes("konserve")){ oyuncu.envanter.splice(oyuncu.envanter.indexOf("konserve"),1); oyuncu.benzin+=10; console.log(c("green","Takas yapıldı! +10 benzin")); } },
      async () => { console.log(c("magenta","\n[OLAY] Çocuk ağlaması... Ama kimse yok. Moral -10")); oyuncu.moral=Math.max(0, oyuncu.moral-10); },
      async () => { console.log(c("cyan","\n[OLAY] Yerde bisiklet! Hız +1")); if(!oyuncu.arac){ oyuncu.arac="Bisiklet"; console.log(c("green","Bisiklet aldın! Haritada daha hızlı hareket ediyorsun.")); } },
      async () => { console.log(c("yellow","\n[OLAY] Benzin istasyonu! Ama pompada zombiler var.")); await savas("yuruyen",2); if(oyuncu.can>0){ oyuncu.benzin+=20; console.log(c("green","+20 benzin!")); } },
      async () => { console.log(c("green","\n[OLAY] Eski bir öğretmen: 'Sana bir şey öğreteyim mi evlat?' +1 Zeka")); oyuncu.yetenekler.zeka++; },
    ];
    await choice(olaylar)();
  }
}

async function bolgeyeGit(){
  let mevcut=HARITA[oyuncu.konum];
  console.log(c("bold", `\n=== ${mevcut.ad} === ${mevcut.aciklama}`));
  console.log("Gidebileceğin yerler:");
  mevcut.baglanti.forEach((id,i)=>{ let b=HARITA[id]; if(!b) return; let kesif=oyuncu.kesfedilen.includes(id)?"":c("yellow"," [YENİ!]"); let tehlike="!".repeat(Math.min(b.tehlike,5)); console.log(` ${i+1}. ${b.ad} ${c("cyan",`[${b.sehir.toUpperCase()}]`)} ${c("red",tehlike)}${kesif}`); });
  console.log(` ${mevcut.baglanti.length+1}. [BÖLGE HARİTASI] Tüm şehirler`);
  console.log(` ${mevcut.baglanti.length+2}. [RADYO DİNLE]`);
  let sec=await ask("Nereye? "); let idx=parseInt(sec)-1;
  if(idx===mevcut.baglanti.length){ await bolgeHaritasiAc(); return; }
  if(idx===mevcut.baglanti.length+1){ asciiRadyo(rand(875,1080)/10, choice(RADYO_MESAJLARI)); return; }
  if(isNaN(idx)||idx<0||idx>=mevcut.baglanti.length){ console.log("Geçersiz."); return; }
  let hedefId=mevcut.baglanti[idx]; oyuncu.konum=hedefId;
  if(!oyuncu.kesfedilen.includes(hedefId)) oyuncu.kesfedilen.push(hedefId);
  oyuncu.saat+= oyuncu.arac==="Bisiklet"?1:rand(1,3); oyuncu.yorgunluk+=5;
  if(oyuncu.saat>=24){ oyuncu.saat-=24; oyuncu.gun++; oyuncu.aclik-=15; oyuncu.susuzluk-=20; oyuncu.hava=choice(["Çok Sıcak","Kum Fırtınası","Serin","Dumanlı"]); console.log(c("yellow", `\n--- Gün ${oyuncu.gun} ---`)); }
  if(oyuncu.aclik<=0){ oyuncu.can-=10; console.log(c("red","Açlıktan ölüyorsun!")); }
  if(oyuncu.susuzluk<=0){ oyuncu.can-=15; console.log(c("red","Susuzluktan bayılıyorsun!")); }
  if(oyuncu.enfeksiyon>=100){ await olumEkrani(true); return; }
  console.log("\n"+c("bold", `>> ${HARITA[hedefId].ad}`)); await typewrite(HARITA[hedefId].aciklama,10); await rastgeleOlayV3();
  if(HARITA[hedefId].guvenli){ console.log(c("green","[GÜVENLİ] Can+10 Moral+15")); oyuncu.can=Math.min(oyuncu.maxCan, oyuncu.can+10); oyuncu.moral=Math.min(100, oyuncu.moral+15); oyuncu.yorgunluk=Math.max(0, oyuncu.yorgunluk-20); oyuncu.itibar[HARITA[hedefId].sehir]=(oyuncu.itibar[HARITA[hedefId].sehir]||0)+5; }
  else { let tehlike=HARITA[hedefId].tehlike; if(rand(1,10)<=Math.ceil(tehlike/2)){ let tur=choice(Object.keys(ZOMBI_TURLERI)); let adet=rand(1, Math.ceil(tehlike/2)); await savas(tur, adet); } else { console.log(c("gray","Sessiz...")); lootYap(hedefId); } }
  if(HARITA[hedefId].final) await finalBolumu();
}

async function bolgeHaritasiAc(){
  console.log(c("cyan", `
  ╔════════════════════════════════════════════════════════╗
  ║  TÜRKİYE GÜNEY BÖLGE HARİTASI V3                         ║
  ║  [ADANA OTOGAR]                                          ║
  ║   ├─> Mersin Yolu -> [MERSİN LİMANI - GEMİ KAÇIŞ]       ║
  ║   ├─> Hatay Yolu -> [HATAY MÜZE - GÜVENLİ]              ║
  ║   ├─> Niğde Yolu -> [KAPADOKYA YERALTI - KAÇIŞ]          ║
  ║   │         └─> Kayseri -> [ERCİYES OTEL - GÜVENLİ]     ║
  ║   ├─> Osmaniye -> Antep -> [ANTEP - BAKIR ZIRH]          ║
  ║   └─> MARAŞ YOLU ████████> [MARAŞ KALESİ - ANA KAÇIŞ]    ║
  ║          ANA HEDEF: MARAŞ KALESİ 200km                   ║
  ╚════════════════════════════════════════════════════════╝
  `));
  console.log(`Keşif: ${oyuncu.kesfedilen.length}/${Object.keys(HARITA).length}`);
  oyuncu.kesfedilen.forEach(id=>{ if(HARITA[id]) console.log(c("green",` ✓ ${HARITA[id].ad}`)); });
  let sec=await ask("Hızlı seyahat şehir yaz (adana/mersin/hatay/nigde/maras/antep/osmaniye/kayseri) boş geç: ");
  if(sec){ let hedefler=Object.keys(HARITA).filter(k=>HARITA[k].sehir===sec); if(hedefler.length>0){ let gidecek=choice(hedefler); if(oyuncu.kesfedilen.includes(gidecek)){ if(oyuncu.benzin>=10||sec==="adana"){ oyuncu.konum=gidecek; oyuncu.benzin=Math.max(0, oyuncu.benzin-10); console.log(c("green",`Hızlı seyahat: ${HARITA[gidecek].ad} -10 benzin`)); } else console.log(c("red","Benzinin yok! Otogarda bul.")); } else console.log("Orayı keşfetmedin."); } }
}

async function craftMenusu(){
  console.log("\n--- CRAFT V3 ---");
  console.log("1. Molotof [benzin + sargi + cakmak] 2. Şalgam [su + tuz + baharat] 3. Tuzlu Ekmek [ekmek + tuz]");
  console.log("4. Barikat [levye + battaniye] 5. Kutsal Bomba [kutsal_su + benzin] 6. Bakır Zırh [antik_para + komur]");
  let sec=await ask("Ne üretmek? (0 iptal): ");
  if(sec==="1"&&oyuncu.envanter.includes("benzin")&&oyuncu.envanter.includes("sargi")){ oyuncu.envanter=oyuncu.envanter.filter(i=>!["benzin","sargi"].includes(i)); oyuncu.envanter.push("molotof"); ESYALAR["molotof"]={ad:"Molotof", tur:"silah", hasar:[40,70], dayaniklilik:1}; console.log(c("green","Molotof yapıldı!")); }
  else if(sec==="2"&&oyuncu.envanter.includes("su")){ oyuncu.envanter.splice(oyuncu.envanter.indexOf("su"),1); oyuncu.susuzluk=Math.min(100, oyuncu.susuzluk+30); oyuncu.moral=Math.min(100, oyuncu.moral+20); console.log(c("green","Şalgam!")); }
  else if(sec==="5"&&oyuncu.envanter.includes("kutsal_su")&&oyuncu.envanter.includes("benzin")){ oyuncu.envanter.splice(oyuncu.envanter.indexOf("kutsal_su"),1); oyuncu.envanter.splice(oyuncu.envanter.indexOf("benzin"),1); oyuncu.envanter.push("kutsal_bomba"); ESYALAR["kutsal_bomba"]={ad:"Kutsal Bomba", tur:"silah", hasar:[80,120], dayaniklilik:1}; console.log(c("green","Kutsal Bomba! Tüm zombilere 80 hasar!")); }
}

async function kayitEt(){ fs.writeFileSync(SAVE_FILE, JSON.stringify(oyuncu,null,2)); console.log(c("green","Kaydedildi -> kayit_v3.json")); }
function kayitYukle(){ if(fs.existsSync(SAVE_FILE)){ try{ let data=JSON.parse(fs.readFileSync(SAVE_FILE)); Object.assign(oyuncu,data); if(!oyuncu.ev.radyoPili) oyuncu.ev.radyoPili=100; if(!oyuncu.yetenekler) oyuncu.yetenekler={guc:1,hiz:1,zeka:1,dayaniklilik:1}; if(!oyuncu.itibar) oyuncu.itibar={adana:0,mersin:0,maras:0,hatay:0,nigde:0}; console.log(c("green","Kayıt yüklendi!")); return true; }catch(e){} } return false; }
async function olumEkrani(enfekte=false){ console.log(c("bgRed","\n\n========== ÖLDÜN ==========")); if(enfekte) await typewrite("Enfeksiyon seni ele geçirdi...",15); else await typewrite("Adana sıcağı bile ısıtamadı.",15); console.log(`Gün:${oyuncu.gun} Kill:${oyuncu.oldurme} Seviye:${oyuncu.seviye}`); let s=await ask("Tekrar? e/h: "); if(s.toLowerCase()==="e"){ oyuncu.can=oyuncu.maxCan; oyuncu.aclik=100; oyuncu.susuzluk=100; oyuncu.konum="ev"; oyuncu.gun=1; } else process.exit(0); }

async function finalBolumu(){
  console.log(c("cyan","\n\n===== FİNAL V3 ====="));
  let bolge=HARITA[oyuncu.konum];
  if(oyuncu.konum==="maras_kale"){
    console.log(c("green",`
    ███╗   ███╗ █████╗ ██████╗  █████╗ ███████╗
    ████╗ ████║██╔══██╗██╔══██╗██╔══██╗██╔════╝
    ██╔████╔██║███████║██████╔╝███████║███████╗
    ██║╚██╔╝██║██╔══██║██╔══██╗██╔══██║╚════██║
    ██║ ╚═╝ ██║██║  ██║██║  ██║██║  ██║███████║
    ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝
          KALESİ - KURTULDUN!
    `));
    await typewrite("Kale kapısı açılıyor... Türk askeri seni içeri çekiyor! İçeride yüzlerce insan, sıcak Maraş çorbası, dondurma bile var! Anons: 'Adana'dan gelen kurtuldu!'",15);
    console.log("\n[1] Kalede kal ve yeni hayat kur (Çiftçi ol)\n[2] Adana'ya geri dönüp kalanları kurtar (Kahraman)\n[3] Radyodan tüm Türkiye'ye seslen (Umut)");
    let sec=await ask("Seçim: ");
    if(sec==="1") await typewrite("Maraş Kalesi artık evin. Adanalı olarak Maraş dondurmasını öğrendin. Tarla ekiyorsun. Hikaye YENİ BAŞLADI. YAŞADIN.",18);
    else if(sec==="2") await typewrite("Silahını aldın, Adana'ya geri dönüyorsun... Adana seni bekler. EFSANE OLDUN.",18);
    else await typewrite("Telsiz: 'Burası Maraş Kalesi! Güvenli! Adana, Mersin, Hatay duyuyorsanız Maraş'a gelin!' Cevap: 'Duyuyoruz! Geliyoruz!' UMUT VAR.",18);
  } else if(oyuncu.konum==="mersin_limani"){
    await typewrite("Mersin Limanı... Son gemi! Kaptan: 'Benzin var mı? Varsa Kıbrıs'a kaçıyoruz!' ",15);
    if(oyuncu.benzin>=20){ await typewrite("Benzini verdin, gemi çalıştı! Akdeniz'e açılıyorsun... Kıbrıs görünüyor. KURTULDUN - DENİZ KAÇIŞI!",18); }
    else { console.log(c("red","Benzinin yok! 20L lazım! Geri dön benzin bul!")); oyuncu.konum="mersin_yolu"; return; }
  } else if(oyuncu.konum==="kapadokya"){
    await typewrite("Kapadokya Yeraltı Şehri... Dar tüneller, mükemmel saklanma. Burada yıllarca yaşayabilirsin. Fenerin varsa güvendesin. YERALTI KAÇIŞI - YAŞADIN!",18);
  } else {
    await typewrite("İncirlik üssü... Kod 4721... Kapı açılıyor... Son uçak kalkıyor! KURTULDUN - HAVA KAÇIŞI!",18);
  }
  oyuncu.bitirdiMi=true; console.log(c("bold","\n*** OYUN BİTTİ - YAŞADIN ***")); fs.writeFileSync("final_kayit_v3.txt", `Oyuncu:${oyuncu.ad} Yıl:${oyuncu.yil} Gün:${oyuncu.gun} Kill:${oyuncu.oldurme} Seviye:${oyuncu.seviye}`); process.exit(0);
}

async function baslangic(){
  console.clear();
  console.log("\x1b[41m\x1b[37m");
  console.log("###############################################################################");
  console.log("#  DİKKAT! ÇİFT TIKLAYARAK AÇMAYIN! WSCRIPT.EXE İLE AÇMAYIN!                   #");
  console.log("#  DOĞRU: node index_3.js  veya  baslat.bat                                   #");
  console.log("#  NODE.JS OLMADAN ÇALIŞMAZ! https://nodejs.org                               #");
  console.log("###############################################################################");
  console.log("\x1b[0m");
  console.log(c("cyan", `  v${VERSION} - SADECE NODE.JS!`));
  console.log(c("red", `
 ███████╗ ██████╗ ███╗   ███╗██████╗ ██╗   ██╗ █████╗
 ╚══███╔╝██╔═══██╗████╗ ████║██╔══██╗██║   ██║██╔══██╗
   ███╔╝ ██║   ██║██╔████╔██║██████╔╝██║   ██║███████║
  ███╔╝  ██║   ██║██║╚██╔╝██║██╔══██╗██║   ██║██╔══██║
 ███████╗╚██████╔╝██║ ╚═╝ ██║██████╔╝╚██████╔╝██║  ██║
 ╚══════╝ ╚═════╝ ╚═╝     ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝
              ADANA - SON DURAK v3.0 MEGA
`));
  await typewrite("Adana, 30.kat... Aşağıda dumanlar. Bu yeni kıyamet. V3'te artık 5 farklı kaçış var: Maraş Kalesi, Mersin Gemisi, Kapadokya Yeraltı, İncirlik Uçağı, Antep Direnişi.",12);
  let devam=await ask("\nKayıtlı oyun var mı? Yükle (y) / Yeni (n): ");
  if(devam.toLowerCase()==="y"){ if(!kayitYukle()) console.log("Kayıt yok, yeni oyun."); }
  if(!oyuncu.ad||oyuncu.ad==="İsimsiz"){
    let ad=await ask("\nAdın ne? (Adanalı isim): "); if(ad) oyuncu.ad=ad; else oyuncu.ad="Garip";
    console.log(c("yellow","\n--- YIL SEÇİMİ ---"));
    Object.keys(YILLAR).forEach(k=>console.log(` [${k}] ${YILLAR[k].ad} - ${YILLAR[k].aciklama}`));
    let yilSec=await ask("Yıl seç (1980/1990/2000/2010/2026): "); if(YILLAR[yilSec]) oyuncu.yil=yilSec; else oyuncu.yil="2026";
    console.log(c("green",`Seçilen yıl: ${YILLAR[oyuncu.yil].ad}`));
    oyuncu.envanter=[...YILLAR[oyuncu.yil].baslangicEsya,"su","battaniye"]; oyuncu.konum="ev"; oyuncu.gun=1; oyuncu.saat=8;
  }
  console.log(c("cyan", `\nHoş geldin ${oyuncu.ad} - ${YILLAR[oyuncu.yil].ad}.`));
  console.log(c("gray","İpucu: İlk 3 gün EVDE kal, hazırlan. Sonra 5 farklı şehir ve kaçış rotası var!"));

  if(oyuncu.gun<=3&&oyuncu.konum==="ev") await ilkUcGunEv();

  while(true){
    oyuncuDurum();
    console.log(c("white", `\nNe yapmak istersin? Gün ${oyuncu.gun}`));
    console.log(" [1] Etrafa bak / Nereye gideceğini karar ver / Haritayı aç");
    console.log(" [2] Bölge haritasını aç (Tüm Türkiye Güney)");
    console.log(" [3] Radyo dinle [ASCII Radyo]");
    console.log(" [4] TV izle [ASCII TV]");
    console.log(" [5] Su iç  [6] Yemek ye  [7] Dinlen  [8] Uyu  [9] Elini aç dua et");
    console.log(" [10] Envanter/Craft/Kaydet/Çıkış  [11] Yetenekler  [12] Araç kullan");
    let komut=(await ask("\n> ")).toLowerCase();
    if(["1","git","etraf","bak"].includes(komut)) await bolgeyeGit();
    else if(["2","harita","map"].includes(komut)) await bolgeHaritasiAc();
    else if(["3","radyo"].includes(komut)){ asciiRadyo(rand(875,1080)/10, choice(RADYO_MESAJLARI)); oyuncu.saat+=1; }
    else if(["4","tv"].includes(komut)){ let kanallar=TV_KANALLARI[oyuncu.yil]||TV_KANALLARI["2026"]; asciiTV(rand(1,10)>3, choice(kanallar)); oyuncu.saat+=1; }
    else if(["5","su"].includes(komut)) await envanterKullan(false);
    else if(["6","yemek"].includes(komut)) await envanterKullan(false);
    else if(["7","dinlen"].includes(komut)){ console.log(c("yellow","Dinleniyorsun...")); await sleep(1000); oyuncu.saat+=1; oyuncu.can=Math.min(oyuncu.maxCan, oyuncu.can+5); oyuncu.yorgunluk=Math.max(0, oyuncu.yorgunluk-15); }
    else if(["8","uyu"].includes(komut)){ console.log(c("yellow","Uyuyorsun...")); await sleep(1500); oyuncu.saat+=6; if(oyuncu.saat>=24){ oyuncu.saat-=24; oyuncu.gun++; } oyuncu.can=Math.min(oyuncu.maxCan, oyuncu.can+15); oyuncu.yorgunluk=0; oyuncu.aclik-=10; oyuncu.susuzluk-=10; if(rand(1,10)>7){ console.log(c("red","Uyurken ısırıldın!")); await savas(choice(Object.keys(ZOMBI_TURLERI)),1); } }
    else if(["9","dua"].includes(komut)){ console.log(c("cyan","Dua ettin...")); oyuncu.moral=Math.min(100, oyuncu.moral+15); oyuncu.can=Math.min(oyuncu.maxCan, oyuncu.can+5); oyuncu.saat+=1; }
    else if(["10","envanter","craft"].includes(komut)){ console.log(" [a] Envanter [b] Craft [c] Kaydet [d] Çıkış"); let alt=await ask("Seç: "); if(alt==="a") await envanterKullan(false); else if(alt==="b") await craftMenusu(); else if(alt==="c") await kayitEt(); else if(alt==="d") break; }
    else if(["11","yetenek"].includes(komut)){ console.log(` Yetenekler: Güç:${oyuncu.yetenekler.guc} Hız:${oyuncu.yetenekler.hiz} Zeka:${oyuncu.yetenekler.zeka} Dayanıklılık:${oyuncu.yetenekler.dayaniklilik}`); let puan=oyuncu.seviye - (oyuncu.yetenekler.guc+oyuncu.yetenekler.hiz+oyuncu.yetenekler.zeka+oyuncu.yetenekler.dayaniklilik-4); console.log(` Kullanılabilir puan: ${puan>0?puan:0}`); if(puan>0){ let sec=await ask("Hangi yetenek? guc/hiz/zeka/dayaniklilik: "); if(oyuncu.yetenekler[sec]!==undefined){ oyuncu.yetenekler[sec]++; console.log(c("green",`${sec} arttı!`)); } } }
    else if(["12","arac","araç"].includes(komut)){ if(oyuncu.arac) console.log(`Aracın: ${oyuncu.arac} Benzin: ${oyuncu.benzin}L`); else console.log("Aracın yok, bisiklet veya araba bulmalısın."); }
    else if(["kaydet"].includes(komut)) await kayitEt();
    else if(["cik","exit","q"].includes(komut)) break;
    else console.log(c("gray","Anlamadım."));
    if(oyuncu.can<=0) await olumEkrani();
  }
  rl.close();
}
baslangic();
